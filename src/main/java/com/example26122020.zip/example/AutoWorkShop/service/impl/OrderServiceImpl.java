package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.OrderService;

public class OrderServiceImpl implements OrderService {
}
