package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.RepairDetailService;

public class RepairDetailServiceImpl implements RepairDetailService {
}
