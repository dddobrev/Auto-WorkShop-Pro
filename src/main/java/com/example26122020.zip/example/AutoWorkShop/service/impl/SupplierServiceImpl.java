package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.SupplierService;

public class SupplierServiceImpl implements SupplierService {
}
