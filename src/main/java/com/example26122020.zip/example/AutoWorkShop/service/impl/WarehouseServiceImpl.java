package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.WarehouseService;

public class WarehouseServiceImpl implements WarehouseService {
}
