package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.AutoPartService;

public class AutoPartServiceImpl implements AutoPartService {
}
