package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.RepairService;

public class RepairServiceImpl implements RepairService {
}
