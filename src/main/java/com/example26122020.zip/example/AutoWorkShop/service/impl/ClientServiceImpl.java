package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.ClientService;

public class ClientServiceImpl implements ClientService {
}
