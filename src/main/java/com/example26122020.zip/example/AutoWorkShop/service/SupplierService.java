package com.example.AutoWorkShop.service;

public interface SupplierService {
}
