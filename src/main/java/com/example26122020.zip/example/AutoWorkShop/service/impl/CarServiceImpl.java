package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.Car;
import com.example.AutoWorkShop.repository.CarRepository;
import com.example.AutoWorkShop.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class CarServiceImpl implements CarService {
    private final CarRepository carRepository;

    @Autowired
    public CarServiceImpl(CarRepository repository) {
        this.carRepository = repository;
    }

    @Override
    public Car findCarByRegNumber(String number) {
        return this.carRepository.findCarByRegNumber(number);
    }

    @Override
    public Car findCarByVin(String vin) {
        return this.carRepository.findCarByVin(vin);
    }
}
