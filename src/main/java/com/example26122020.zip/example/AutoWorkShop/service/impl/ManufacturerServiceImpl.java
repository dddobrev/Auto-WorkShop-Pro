package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.ManufacturerService;

public class ManufacturerServiceImpl implements ManufacturerService {
}
