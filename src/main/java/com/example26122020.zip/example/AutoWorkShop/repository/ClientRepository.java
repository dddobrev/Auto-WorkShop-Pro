package com.example.AutoWorkShop.repository;

import com.example.AutoWorkShop.domain.entities.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends JpaRepository<Client, Long> {
    Client findClientByFirstName(String name);
    Client findClientByTelephone(String telephoneNumber);
}
