package com.example.AutoWorkShop.repository;

import com.example.AutoWorkShop.domain.entities.AutoPart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AutoPartRepository extends JpaRepository<AutoPart, Long> {
    AutoPart findByPartNumber(String number);
    AutoPart findByPartOeNumber(String oeNumber);
    List<AutoPart> findAutoPartByName(String name);
}
