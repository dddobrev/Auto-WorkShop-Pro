package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;

@Entity(name = "auto_part_quality")
public class AutoPartQuality extends BaseEntity{
    private AutoPart autoPart;
    private Integer partWorkload;
    private Integer partKm;
    private Integer score;

    public AutoPartQuality() {
    }

    @ManyToOne(targetEntity = AutoPart.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "auto_parts_id", referencedColumnName = "id")
    public AutoPart getAutoPart() {
        return autoPart;
    }

    @Column(name = "part_workload")
    public Integer getPartWorkload() {
        return partWorkload;
    }

    @Column(name = "part_km")
    public Integer getPartKm() {
        return partKm;
    }

    @Column(name = "score")
    public Integer getScore() {
        return score;
    }

    public void setAutoPart(AutoPart autoPart) {
        this.autoPart = autoPart;
    }

    public void setPartWorkload(Integer part_workload) {
        this.partWorkload = part_workload;
    }

    public void setPartKm(Integer part_km) {
        this.partKm = part_km;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
