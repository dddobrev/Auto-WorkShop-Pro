package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Set;

@Entity(name = "cars")
public class Car extends BaseEntity {
    private String regNumber;
    private String vin;
    private String brand;
    private String model;
    private String engine;
    private Integer volume;
    private Integer power;
    private String fuel;
    private LocalDate releaseDate;
    private Client client;
    private Integer mileage;
    private Integer mileageDifferent;
    private Set<Order> orders;
    private Set<Repair> repairs;

    public Car() {
    }

    @Column(name = "reg_number")
    public String getRegNumber() {
        return regNumber;
    }

    @Column(name = "vin")
    public String getVin() {
        return vin;
    }

    @Column(name = "brand")
    public String getBrand() {
        return brand;
    }

    @Column(name = "model")
    public String getModel() {
        return model;
    }

    @Column(name = "engine")
    public String getEngine() {
        return engine;
    }

    @Column(name = "volume")
    public Integer getVolume() {
        return volume;
    }

    @Column(name = "power_ps")
    public Integer getPower() {
        return power;
    }

    @Column(name = "fuel")
    public String getFuel() {
        return fuel;
    }

    @Column(name = "release_date")
    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    @ManyToOne(targetEntity = Client.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "client_id", referencedColumnName = "id")
    public Client getClient() {
        return client;
    }

    @Column(name = "miliage")
    public Integer getMileage() {
        return mileage;
    }

    @Column(name = "miliage_diffrent")
    public Integer getMileageDifferent() {
        return mileageDifferent;
    }

    @OneToMany(mappedBy = "car")
    public Set<Order> getOrders() {
        return orders;
    }

    @OneToMany(mappedBy = "car")
    public Set<Repair> getRepairs() {
        return repairs;
    }


    public void setRegNumber(String regNumber) {
        this.regNumber = regNumber;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public void setMileageDifferent(Integer mileageDifferent) {
        this.mileageDifferent = mileageDifferent;
    }

    public void setOrders(Set<Order> orders) {
        this.orders = orders;
    }

    public void setRepairs(Set<Repair> repairs) {
        this.repairs = repairs;
    }

}
