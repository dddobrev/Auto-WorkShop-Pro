package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.time.LocalDate;

@Entity(name = "orders")
public class Order extends BaseEntity {
    private LocalDate dataOrder;
    private Car car;
    private String problems;
    private String comment;
    private LocalDate dataIn;
    private LocalDate dataOut;

    public Order() {
    }

    @Column(name = "data_order")
    public LocalDate getDataOrder() {
        return dataOrder;
    }

    @ManyToOne(targetEntity = Car.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "cars_id", referencedColumnName = "id")
    public Car getCar() {
        return car;
    }

    @Column(name = "problems")
    public String getProblems() {
        return problems;
    }

    @Column(name = "comment")
    public String getComment() {
        return comment;
    }

    @Column(name = "data_in")
    public LocalDate getDataIn() {
        return dataIn;
    }

    @Column(name = "data_out")
    public LocalDate getDataOut() {
        return dataOut;
    }

    public void setDataOrder(LocalDate dataOrder) {
        this.dataOrder = dataOrder;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public void setProblems(String problems) {
        this.problems = problems;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setDataIn(LocalDate dataIn) {
        this.dataIn = dataIn;
    }

    public void setDataOut(LocalDate dataOut) {
        this.dataOut = dataOut;
    }
}
