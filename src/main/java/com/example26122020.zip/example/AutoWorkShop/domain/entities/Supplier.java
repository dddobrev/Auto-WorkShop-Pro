package com.example.AutoWorkShop.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name = "supplier")
public class Supplier extends BaseEntity{
    private String supplierName;
    private String supplierTelephone;
    private String supplierContactPerson;

    public Supplier() {
    }

    @Column(name = "supplier_name")
    public String getSupplierName() {
        return supplierName;
    }

    @Column(name = "supplier_telephone")
    public String getSupplierTelephone() {
        return supplierTelephone;
    }

    @Column(name = "supplier_contact_person")
    public String getSupplierContactPerson() {
        return supplierContactPerson;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setSupplierTelephone(String supplierTelephone) {
        this.supplierTelephone = supplierTelephone;
    }

    public void setSupplierContactPerson(String supplierContactPerson) {
        this.supplierContactPerson = supplierContactPerson;
    }
}
