package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;

@Entity(name = "repair_details")
public class RepairDetail extends BaseEntity{
    private Repair repair;
    private String repairDescription;
    private String remarks;
    private BigDecimal price;
    private Set<AutoPart> autoParts;

    public RepairDetail() {
    }

    @ManyToOne(targetEntity = Repair.class,
            cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "repair_id", referencedColumnName = "id")
    public Repair getRepair() {
        return repair;
    }

    @Column(name = "repair_description")
    public String getRepairDescription() {
        return repairDescription;
    }

    @Column(name = "remarks")
    public String getRemarks() {
        return remarks;
    }

    @Column(name = "price")
    public BigDecimal getPrice() {
        return price;
    }

    @OneToMany(mappedBy = "repairDetail")
    public Set<AutoPart> getAutoParts() {
        return autoParts;
    }

    public void setRepair(Repair repair) {
        this.repair = repair;
    }

    public void setRepairDescription(String repairDescription) {
        this.repairDescription = repairDescription;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setAutoParts(Set<AutoPart> autoParts) {
        this.autoParts = autoParts;
    }
}
