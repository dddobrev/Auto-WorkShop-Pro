package com.example.AutoWorkShop.controller;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet ("/")
public class HomeController extends HttpServlet {

}
