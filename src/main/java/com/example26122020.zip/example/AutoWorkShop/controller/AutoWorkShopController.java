package com.example.AutoWorkShop.controller;

import com.example.AutoWorkShop.domain.entities.Car;
import com.example.AutoWorkShop.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

import java.util.Scanner;

@Controller
@Transactional
public class AutoWorkShopController implements CommandLineRunner {

    private final CarService carService;

    @Autowired
    public AutoWorkShopController(CarService carService) {
        this.carService = carService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please put car's number ");
        String carNumber = scanner.nextLine();
//        Car carByRegNumber = this.carService.findCarByRegNumber(carNumber);
        Car carByRegNumber = this.carService.findCarByVin(carNumber);

        System.out.printf("%s %s, engine %s, volume %ssm3, VIN %s, %s",
                carByRegNumber.getBrand(),
                carByRegNumber.getModel(),
                carByRegNumber.getEngine(),
                carByRegNumber.getVolume(),
                carByRegNumber.getVin(),
                carByRegNumber.getClient().getFirstName());
    }
}
