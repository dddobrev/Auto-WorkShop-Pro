package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.AutoPartQualityService;

public class AutoPartQualityServiceImpl implements AutoPartQualityService {
}
