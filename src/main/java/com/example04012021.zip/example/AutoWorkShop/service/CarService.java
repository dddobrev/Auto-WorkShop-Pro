package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Car;

import java.io.IOException;
import java.util.List;

public interface CarService {
    Car findCarByRegNumber(String number);

    Car findCarByVin(String vin);

    void inputCar() throws IOException;

}
