package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Car;
import com.example.AutoWorkShop.domain.entities.Order;

import java.util.List;

public interface OrderService {
    List<Order> findOrderByCarBrand(String carBrand);
    List<Order> findOrderByCarVin(String carVin);
    List<Order> findOrderByCarRegNumber(String carRegNumber);
}
