package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.Car;
import com.example.AutoWorkShop.domain.entities.Order;
import com.example.AutoWorkShop.repository.OrderRepository;
import com.example.AutoWorkShop.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    public List<Order> findOrderByCarBrand(String carBrand) {
        return this.orderRepository.findOrderByCarBrand(carBrand);
    }

    @Override
    public List<Order> findOrderByCarVin(String carVin) {
        return this.orderRepository.findOrderByCarVin(carVin);
    }

    @Override
    public List<Order> findOrderByCarRegNumber(String carRegNumber) {
        return this.orderRepository.findOrderByCarRegNumber(carRegNumber);
    }
}
