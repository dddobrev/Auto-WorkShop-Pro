package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.AutoPart;

import java.util.List;

public interface AutoPartService {
    AutoPart findAutoPartByNumber(String number);
    List<AutoPart> findAutoPartByOeNumber(String oeNumber);
    List<AutoPart> findAutoPartsByName(String name);
}
