package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Order;
import com.example.AutoWorkShop.domain.entities.Repair;

import java.util.List;

public interface RepairService {
    List<Repair> findOrderByCarName(String carName);
    List<Repair> findOrderByCarVin(String carVin);
    List<Repair> findOrderByCarRegNumber(String carRegNumber);
    List<Repair> findAllByCarVin(String carVin);
}
