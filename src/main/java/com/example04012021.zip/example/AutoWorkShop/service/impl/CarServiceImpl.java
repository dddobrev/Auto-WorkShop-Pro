package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.Car;
import com.example.AutoWorkShop.domain.util.FileUtil;
import com.example.AutoWorkShop.repository.CarRepository;
import com.example.AutoWorkShop.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;


@Service
@Transactional
public class CarServiceImpl implements CarService {
    private final static String CAR_PATH = "";
    private final CarRepository carRepository;
    private final FileUtil fileUtil;

    @Autowired
    public CarServiceImpl(CarRepository repository, FileUtil fileUtil) {
        this.carRepository = repository;
        this.fileUtil = fileUtil;
    }

    @Override
    public Car findCarByRegNumber(String number) {
        return this.carRepository.findCarByRegNumber(number);
    }

    @Override
    public Car findCarByVin(String vin) {
        return this.carRepository.findCarByVin(vin);
    }

    @Override
    public void inputCar() throws IOException {
        String[] carContent = this.fileUtil.getFileContent(CAR_PATH);

        Car car = new Car();

    }
}
