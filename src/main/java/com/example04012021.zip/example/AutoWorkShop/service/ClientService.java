package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Client;

import java.util.List;

public interface ClientService {
    List<Client> findClientByName(String name);
    List<Client> findClientByTelephone(String telephone);
}
