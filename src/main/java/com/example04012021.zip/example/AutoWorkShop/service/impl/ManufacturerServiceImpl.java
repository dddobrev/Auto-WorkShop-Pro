package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.Manufacturer;
import com.example.AutoWorkShop.repository.ManufacturerRepository;
import com.example.AutoWorkShop.service.ManufacturerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ManufacturerServiceImpl implements ManufacturerService {
    private final ManufacturerRepository manufacturerRepository;

    @Autowired
    public ManufacturerServiceImpl(ManufacturerRepository manufacturerRepository) {
        this.manufacturerRepository = manufacturerRepository;
    }

    @Override
    public Manufacturer findManufacturerByName(String name) {
        return this.manufacturerRepository.findManufacturerByManufacturerName(name);
    }
}
