package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Supplier;

public interface SupplierService {
    Supplier findSupplierByName(String supplierName);
}
