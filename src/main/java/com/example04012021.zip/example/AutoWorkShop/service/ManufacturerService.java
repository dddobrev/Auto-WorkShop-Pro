package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.Manufacturer;

public interface ManufacturerService {
    Manufacturer findManufacturerByName(String name);
}
