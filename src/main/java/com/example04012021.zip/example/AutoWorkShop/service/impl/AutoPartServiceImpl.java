package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.AutoPart;
import com.example.AutoWorkShop.repository.AutoPartRepository;
import com.example.AutoWorkShop.service.AutoPartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AutoPartServiceImpl implements AutoPartService {
    private final AutoPartRepository autoPartRepository;

    @Autowired
    public AutoPartServiceImpl(AutoPartRepository autoPartRepository) {
        this.autoPartRepository = autoPartRepository;
    }

    @Override
    public AutoPart findAutoPartByNumber(String number) {
        return autoPartRepository.findByPartNumber(number);
    }

    @Override
    public List<AutoPart> findAutoPartByOeNumber(String oeNumber) {
        return autoPartRepository.findByPartOeNumber(oeNumber);
    }

    @Override
    public List<AutoPart> findAutoPartsByName(String name) {
        return this.autoPartRepository.findAutoPartByName(name);
    }
}
