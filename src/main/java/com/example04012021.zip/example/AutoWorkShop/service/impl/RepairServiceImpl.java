package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.Repair;
import com.example.AutoWorkShop.repository.RepairRepository;
import com.example.AutoWorkShop.service.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RepairServiceImpl implements RepairService {
    private final RepairRepository repairRepository;

    @Autowired
    public RepairServiceImpl(RepairRepository repairRepository) {
        this.repairRepository = repairRepository;
    }

    @Override
    public List<Repair> findOrderByCarName(String carName) {
        return this.repairRepository.findRepairByCar_Brand(carName);
    }

    @Override
    public List<Repair> findOrderByCarVin(String carVin) {
        return this.repairRepository.findRepairByCarVin(carVin);
    }

    @Override
    public List<Repair> findOrderByCarRegNumber(String carRegNumber) {
        return this.repairRepository.findRepairByCar_RegNumber(carRegNumber);
    }

    @Override
    public List<Repair> findAllByCarVin(String carVin) {
        return this.repairRepository.findAllByCar_Vin(carVin);
    }
}
