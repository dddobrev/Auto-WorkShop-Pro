package com.example.AutoWorkShop.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity(name = "manufacturer")
public class Manufacturer extends BaseEntity{
    private String manufacturerName;
    private Set<AutoPart> autoParts;

    public Manufacturer() {
    }

    public Manufacturer(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    @Column(name = "manufacturer_name", nullable = false)
    public String getManufacturerName() {
        return manufacturerName;
    }

    @OneToMany(mappedBy = "manufacturer")
    public Set<AutoPart> getAutoParts() {
        return autoParts;
    }

    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    public void setAutoParts(Set<AutoPart> autoParts) {
        this.autoParts = autoParts;
    }
}
