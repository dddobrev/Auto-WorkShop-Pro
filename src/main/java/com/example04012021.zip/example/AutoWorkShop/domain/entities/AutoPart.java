package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;

@Entity(name = "auto_parts")
public class AutoPart extends BaseEntity{
    private Supplier supplier;
    private Manufacturer manufacturer;
    private String name;
    private String partNumber;
    private String partOeNumber;
    private BigDecimal priceIn;
    private BigDecimal priceOut;
    private RepairDetail repairDetail;
    private Set<Warehouse> warehouses;

    public AutoPart() {
    }

    @ManyToOne(targetEntity = Supplier.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "supplier_id", referencedColumnName = "id")
    public Supplier getSupplier() {
        return supplier;
    }

    @ManyToOne(targetEntity = Manufacturer.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "manufacturer_id", referencedColumnName = "id")
    public Manufacturer getManufacturer() {
        return manufacturer;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    @Column(name = "part_number")
    public String getPartNumber() {
        return partNumber;
    }

    @Column(name = "part_oe_number")
    public String getPartOeNumber() {
        return partOeNumber;
    }

    @Column(name = "price_in")
    public BigDecimal getPriceIn() {
        return priceIn;
    }

    @Column(name = "price_out")
    public BigDecimal getPriceOut() {
        return priceOut;
    }

    @ManyToOne(targetEntity = RepairDetail.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "repair_details_id", referencedColumnName = "id")
    public RepairDetail getRepairDetail() {
        return repairDetail;
    }

    @OneToMany(mappedBy = "autoParts")
    public Set<Warehouse> getWarehouses() {
        return warehouses;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public void setManufacturer(Manufacturer manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public void setPartOeNumber(String partOeNumber) {
        this.partOeNumber = partOeNumber;
    }

    public void setPriceIn(BigDecimal priceIn) {
        this.priceIn = priceIn;
    }

    public void setPriceOut(BigDecimal priceOut) {
        this.priceOut = priceOut;
    }

    public void setRepairDetail(RepairDetail repairDetail) {
        this.repairDetail = repairDetail;
    }

    public void setWarehouses(Set<Warehouse> warehouses) {
        this.warehouses = warehouses;
    }
}
