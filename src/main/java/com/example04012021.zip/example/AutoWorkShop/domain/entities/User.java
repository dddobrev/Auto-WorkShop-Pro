package com.example.AutoWorkShop.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.time.LocalDate;

@Entity
public class User extends BaseEntity {
    private String name;
    private String password;
    private LocalDate loginInfo;

    public User() {
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    @Column(name = "password")
    public String getPassword() {
        return password;
    }

    @Column(name = "login_info")
    public LocalDate getLoginInfo() {
        return loginInfo;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLoginInfo(LocalDate loginInfo) {
        this.loginInfo = loginInfo;
    }
}
