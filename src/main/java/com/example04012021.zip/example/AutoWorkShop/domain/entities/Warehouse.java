package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.util.Set;

@Entity(name = "warehouse")
public class Warehouse extends BaseEntity {
    private AutoPart autoParts;
    private Integer piece;

    public Warehouse() {
    }

    @ManyToOne(targetEntity = AutoPart.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "auto_parts_id", referencedColumnName = "id")
    public AutoPart getAutoParts() {
        return autoParts;
    }

    @Column(name = "piece")
    public Integer getPiece() {
        return this.piece;
    }

    public void setAutoParts(AutoPart autoParts) {
        this.autoParts = autoParts;
    }

    public void setPiece(Integer piece) {
        this.piece = piece;
    }
}
