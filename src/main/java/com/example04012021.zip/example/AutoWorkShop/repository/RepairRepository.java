package com.example.AutoWorkShop.repository;

import com.example.AutoWorkShop.domain.entities.Repair;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepairRepository extends JpaRepository<Repair, Long> {
    List<Repair> findRepairByCar_Brand(String carBrand);
    List<Repair> findRepairByCarVin(String carVin);
    List<Repair> findRepairByCar_RegNumber(String carRegNumber);
    List<Repair> findAllByCar_Vin(String carVin);
}
