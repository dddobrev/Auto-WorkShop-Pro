package com.example.AutoWorkShop.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity(name = "manufacturer")
public class ManufacturerEntity extends BaseEntity{
    private String manufacturerName;
    private Set<AutoPartEntity> autoPartEntities;

    public ManufacturerEntity() {
    }

    public ManufacturerEntity(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    @Column(name = "manufacturer_name", nullable = false)
    public String getManufacturerName() {
        return manufacturerName;
    }

    @OneToMany(mappedBy = "manufacturer")
    public Set<AutoPartEntity> getAutoParts() {
        return autoPartEntities;
    }

    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    public void setAutoParts(Set<AutoPartEntity> autoPartEntities) {
        this.autoPartEntities = autoPartEntities;
    }
}
