package com.example.AutoWorkShop.domain.entities.enums;

public enum UserRoleEnum {
    ADMIN, USER
}
