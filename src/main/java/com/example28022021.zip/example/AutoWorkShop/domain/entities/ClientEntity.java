package com.example.AutoWorkShop.domain.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity(name = "client")
public class ClientEntity extends BaseEntity{

    private String firstName;
    private String secondName;
    private String telephone;
    private Set<CarEntity> carEntities;

    public ClientEntity() {
    }

    @Column(name = "first_name")
    public String getFirstName() {
        return firstName;
    }

    @Column(name = "second_name")
    public String getSecondName() {
        return secondName;
    }

    @Column(name = "telephone")
    public String getTelephone() {
        return telephone;
    }

    @OneToMany(mappedBy = "client")
    public Set<CarEntity> getCars() {
        return carEntities;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setCars(Set<CarEntity> carEntities) {
        this.carEntities = carEntities;
    }

}
