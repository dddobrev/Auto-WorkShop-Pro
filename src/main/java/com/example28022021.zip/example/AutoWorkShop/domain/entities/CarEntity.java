package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Set;

@Entity(name = "cars")
public class CarEntity extends BaseEntity {
    private String regNumber;
    private String vin;
    private String brand;
    private String model;
    private String engine;
    private Integer volume;
    private Integer power;
    private String fuel;
    private LocalDate releaseDate;
    private ClientEntity clientEntity;
    private Integer mileage;
    private Integer mileageDifferent;
    private Set<OrderEntity> orderEntities;
    private Set<RepairEntity> repairEntities;

    public CarEntity() {
    }

    @Column(name = "reg_number")
    public String getRegNumber() {
        return regNumber;
    }

    @Column(name = "vin")
    public String getVin() {
        return vin;
    }

    @Column(name = "brand")
    public String getBrand() {
        return brand;
    }

    @Column(name = "model")
    public String getModel() {
        return model;
    }

    @Column(name = "engine")
    public String getEngine() {
        return engine;
    }

    @Column(name = "volume")
    public Integer getVolume() {
        return volume;
    }

    @Column(name = "power_ps")
    public Integer getPower() {
        return power;
    }

    @Column(name = "fuel")
    public String getFuel() {
        return fuel;
    }

    @Column(name = "release_date")
    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    @ManyToOne(targetEntity = ClientEntity.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "client_id", referencedColumnName = "id")
    public ClientEntity getClient() {
        return clientEntity;
    }

    @Column(name = "miliage")
    public Integer getMileage() {
        return mileage;
    }

    @Column(name = "miliage_diffrent")
    public Integer getMileageDifferent() {
        return mileageDifferent;
    }

    @OneToMany(mappedBy = "car")
    public Set<OrderEntity> getOrders() {
        return orderEntities;
    }

    @OneToMany(mappedBy = "car")
    public Set<RepairEntity> getRepairs() {
        return repairEntities;
    }


    public void setRegNumber(String regNumber) {
        this.regNumber = regNumber;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setClient(ClientEntity clientEntity) {
        this.clientEntity = clientEntity;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public void setMileageDifferent(Integer mileageDifferent) {
        this.mileageDifferent = mileageDifferent;
    }

    public void setOrders(Set<OrderEntity> orderEntities) {
        this.orderEntities = orderEntities;
    }

    public void setRepairs(Set<RepairEntity> repairEntities) {
        this.repairEntities = repairEntities;
    }

}
