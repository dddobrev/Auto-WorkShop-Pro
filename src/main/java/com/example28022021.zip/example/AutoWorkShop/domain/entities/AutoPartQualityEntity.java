package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;

@Entity(name = "auto_part_quality")
public class AutoPartQualityEntity extends BaseEntity{
    private AutoPartEntity autoPartEntity;
    private Integer partWorkload;
    private Integer partKm;
    private Integer score;

    public AutoPartQualityEntity() {
    }

    @ManyToOne(targetEntity = AutoPartEntity.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "auto_parts_id", referencedColumnName = "id")
    public AutoPartEntity getAutoPart() {
        return autoPartEntity;
    }

    @Column(name = "part_workload")
    public Integer getPartWorkload() {
        return partWorkload;
    }

    @Column(name = "part_km")
    public Integer getPartKm() {
        return partKm;
    }

    @Column(name = "score")
    public Integer getScore() {
        return score;
    }

    public void setAutoPart(AutoPartEntity autoPartEntity) {
        this.autoPartEntity = autoPartEntity;
    }

    public void setPartWorkload(Integer part_workload) {
        this.partWorkload = part_workload;
    }

    public void setPartKm(Integer part_km) {
        this.partKm = part_km;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
