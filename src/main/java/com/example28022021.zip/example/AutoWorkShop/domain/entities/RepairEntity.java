package com.example.AutoWorkShop.domain.entities;

import javax.persistence.*;
import java.time.LocalDate;

@Entity(name = "repair")
public class RepairEntity extends  BaseEntity{

    private CarEntity carEntity;
    private Integer oldKm;
    private Integer newKm;
    private LocalDate dataInGarage;
    private LocalDate dataOutGarage;

    public RepairEntity() {
    }

    @ManyToOne(targetEntity = CarEntity.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "cars_id", referencedColumnName = "id")
    public CarEntity getCar() {
        return carEntity;
    }

    @Column(name = "old_km")
    public Integer getOldKm() {
        return oldKm;
    }

    @Column(name = "new_km")
    public Integer getNewKm() {
        return newKm;
    }

    @Column(name = "data_in_garage")
    public LocalDate getDataInGarage() {
        return dataInGarage;
    }

    @Column(name = "data_out_garage")
    public LocalDate getDataOutGarage() {
        return dataOutGarage;
    }

    public void setCar(CarEntity carEntity) {
        this.carEntity = carEntity;
    }

    public void setOldKm(Integer oldKm) {
        this.oldKm = oldKm;
    }

    public void setNewKm(Integer newKm) {
        this.newKm = newKm;
    }

    public void setDataInGarage(LocalDate dataInGarage) {
        this.dataInGarage = dataInGarage;
    }

    public void setDataOutGarage(LocalDate dataOutGarage) {
        this.dataOutGarage = dataOutGarage;
    }
}
