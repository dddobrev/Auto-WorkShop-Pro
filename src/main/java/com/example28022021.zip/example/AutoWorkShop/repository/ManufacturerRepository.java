package com.example.AutoWorkShop.repository;

import com.example.AutoWorkShop.domain.entities.ManufacturerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManufacturerRepository extends JpaRepository<ManufacturerEntity, Long> {
    ManufacturerEntity findManufacturerByManufacturerName(String name);
}
