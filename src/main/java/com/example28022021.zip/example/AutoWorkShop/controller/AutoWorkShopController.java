package com.example.AutoWorkShop.controller;

import com.example.AutoWorkShop.domain.entities.CarEntity;
import com.example.AutoWorkShop.service.CarService;
import com.example.AutoWorkShop.service.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

import java.util.Scanner;

@Controller
@Transactional
public class AutoWorkShopController implements CommandLineRunner {

    private final CarService carService;
    private final RepairService repairService;

    @Autowired
    public AutoWorkShopController(CarService carService, RepairService repairService) {
        this.carService = carService;
        this.repairService = repairService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please put car's number ");
        String input = scanner.nextLine();
        if (input.equalsIgnoreCase("car")) {
            String brand = scanner.nextLine();
        }
        CarEntity carEntityByRegNumber = this.carService.findCarByRegNumber(input);
//        Car carByRegNumber = this.carService.findCarByVin(carNumber);
//        List<RepairEntity> carByRegNumber = this.repairService.findOrderByCarName(carNumber);
//        List<RepairEntity> carByRegNumber = this.repairService.findAllByCarVin(input);
        if (carEntityByRegNumber != null) {
            System.out.printf("%s %s, engine %s, volume %ssm3, VIN %s, %s",
                    carEntityByRegNumber.getBrand(),
                    carEntityByRegNumber.getModel(),
                    carEntityByRegNumber.getEngine(),
                    carEntityByRegNumber.getVolume(),
                    carEntityByRegNumber.getVin(),
                    carEntityByRegNumber.getClient().getFirstName());

        } else {
            System.out.println("not found");
        }
    }
}
