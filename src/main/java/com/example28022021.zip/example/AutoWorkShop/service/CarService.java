package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.CarEntity;
import com.example.AutoWorkShop.domain.entities.CarEntity;

import java.io.IOException;
import java.util.List;

public interface CarService {
    CarEntity findCarByRegNumber(String number);

    CarEntity findCarByVin(String vin);

    void inputCar() throws IOException;

}
