package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.ManufacturerEntity;

public interface ManufacturerService {
    ManufacturerEntity findManufacturerByName(String name);
}
