package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.AutoPartEntity;

import java.util.List;

public interface AutoPartService {
    AutoPartEntity findAutoPartByNumber(String number);
    List<AutoPartEntity> findAutoPartByOeNumber(String oeNumber);
    List<AutoPartEntity> findAutoPartsByName(String name);
}
