package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.SupplierEntity;
import com.example.AutoWorkShop.repository.SupplierRepository;
import com.example.AutoWorkShop.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SupplierServiceImpl implements SupplierService {
    private final SupplierRepository supplierRepository;

    @Autowired
    public SupplierServiceImpl(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    @Override
    public SupplierEntity findSupplierByName(String supplierName) {
        return this.supplierRepository.findSupplierBySupplierNameContains(supplierName);
    }
}
