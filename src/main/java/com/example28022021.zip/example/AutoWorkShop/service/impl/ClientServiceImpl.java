package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.domain.entities.ClientEntity;
import com.example.AutoWorkShop.repository.ClientRepository;
import com.example.AutoWorkShop.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ClientServiceImpl implements ClientService {
    private final ClientRepository clientRepository;

    @Autowired
    public ClientServiceImpl(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    @Override
    public List<ClientEntity> findClientByName(String name) {
        return this.clientRepository.findClientByFirstName(name);
    }

    @Override
    public List<ClientEntity> findClientByTelephone(String telephone) {
        return this.clientRepository.findClientByTelephone(telephone);
    }
}
