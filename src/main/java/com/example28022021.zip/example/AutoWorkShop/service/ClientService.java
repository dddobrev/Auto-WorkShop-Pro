package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.ClientEntity;

import java.util.List;

public interface ClientService {
    List<ClientEntity> findClientByName(String name);
    List<ClientEntity> findClientByTelephone(String telephone);
}
