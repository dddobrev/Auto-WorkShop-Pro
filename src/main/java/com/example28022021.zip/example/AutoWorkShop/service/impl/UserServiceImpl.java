package com.example.AutoWorkShop.service.impl;

import com.example.AutoWorkShop.service.UserService;

public class UserServiceImpl implements UserService {
}
