package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.SupplierEntity;

public interface SupplierService {
    SupplierEntity findSupplierByName(String supplierName);
}
