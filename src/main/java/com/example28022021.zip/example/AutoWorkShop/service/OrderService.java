package com.example.AutoWorkShop.service;

import com.example.AutoWorkShop.domain.entities.OrderEntity;

import java.util.List;

public interface OrderService {
    List<OrderEntity> findOrderByCarBrand(String carBrand);
    List<OrderEntity> findOrderByCarVin(String carVin);
    List<OrderEntity> findOrderByCarRegNumber(String carRegNumber);
}
